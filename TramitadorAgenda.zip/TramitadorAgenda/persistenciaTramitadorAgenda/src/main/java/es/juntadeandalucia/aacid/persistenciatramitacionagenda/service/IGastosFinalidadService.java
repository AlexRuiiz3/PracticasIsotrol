package es.juntadeandalucia.aacid.persistenciatramitacionagenda.service;

public interface IGastosFinalidadService {

}
