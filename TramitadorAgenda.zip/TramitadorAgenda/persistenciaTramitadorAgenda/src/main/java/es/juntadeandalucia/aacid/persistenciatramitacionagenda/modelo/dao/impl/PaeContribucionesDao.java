package es.juntadeandalucia.aacid.persistenciatramitacionagenda.modelo.dao.impl;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.NoResultException;
import es.juntadeandalucia.aacid.comuntramitacion.exception.TramitacionException;
import es.juntadeandalucia.aacid.persistenciatramitacionagenda.modelo.dao.IPaeContribucionesDao;
import es.juntadeandalucia.aacid.persistenciatramitacionagenda.modelo.entidad.sistemaantiguo.PaeContribuciones;
import es.juntadeandalucia.aacid.persistenciatramitacionagenda.persistence.CustomHibernateDaoSupport;

public class PaeContribucionesDao extends CustomHibernateDaoSupport implements IPaeContribucionesDao{

  @Override
  public List<PaeContribuciones> getPaeContribucionesBySolicitud(Long idSolicitud) throws TramitacionException {
    try {
      return getEntityManagerAntiguo().createQuery(
          "select contribuciones from PaeContribuciones contribuciones where contribuciones.paeSolicitudes.idSolicitud = :paeSolicitudes", PaeContribuciones.class)
          .setParameter("paeSolicitudes", Integer.parseInt(String.valueOf(idSolicitud))).getResultList();
    }catch (NoResultException nre){
      return new  ArrayList<>();
    }catch (Exception e) {
      throw new TramitacionException("Error obteniendo las entidades contribuciones de la solicitud: "
          + idSolicitud+". Causa: " + e.getMessage());

    }
  }

}
