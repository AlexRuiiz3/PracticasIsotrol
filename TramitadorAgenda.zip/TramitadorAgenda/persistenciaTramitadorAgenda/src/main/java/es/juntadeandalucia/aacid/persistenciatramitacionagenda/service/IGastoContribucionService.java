package es.juntadeandalucia.aacid.persistenciatramitacionagenda.service;

import es.juntadeandalucia.aacid.comuntramitacion.dto.ValidaPresupuestoDTO;

public interface IGastoContribucionService {

  void anyadeGastoContribucionAEntidad(ValidaPresupuestoDTO validaPresupuestoDTO);
}
