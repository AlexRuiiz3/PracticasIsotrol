package es.juntadeandalucia.aacid.persistenciatramitacionagenda.service.impl;

public class GastosFinalidadService {

}
