package es.juntadeandalucia.aacid.persistenciatramitacionagenda.service;

import es.juntadeandalucia.aacid.persistenciatramitacionagenda.modelo.entidad.sistemaantiguo.PaePaises;

public interface IPaePaisesService {
	public PaePaises getPaisById(Long id);

}
