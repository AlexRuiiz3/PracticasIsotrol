package es.juntadeandalucia.aacid.persistenciatramitacionagenda.modelo.dao;

public interface IPaisSolicitudDao {
	String obtenerPaisesSeparadosPorComaBySolicitud (Long idSolicitud);
}
