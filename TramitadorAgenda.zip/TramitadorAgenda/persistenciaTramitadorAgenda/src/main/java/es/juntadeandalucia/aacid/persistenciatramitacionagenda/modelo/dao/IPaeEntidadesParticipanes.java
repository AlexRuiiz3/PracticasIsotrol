package es.juntadeandalucia.aacid.persistenciatramitacionagenda.modelo.dao;

public interface IPaeEntidadesParticipanes {

}
