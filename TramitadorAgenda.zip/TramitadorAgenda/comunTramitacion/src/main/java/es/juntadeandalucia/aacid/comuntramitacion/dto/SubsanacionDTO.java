package es.juntadeandalucia.aacid.comuntramitacion.dto;

public class SubsanacionDTO {


}
