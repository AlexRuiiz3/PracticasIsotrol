package es.juntadeandalucia.aacid.comuntramitacion.validation.groups;

/**
 * Grupo de validación para fecha
 * 
 * @author isotrol
 */
public interface ConstraintsFechaAnteriorActual {

}
