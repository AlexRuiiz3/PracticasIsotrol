package es.juntadeandalucia.aacid.comuntramitacion.validation.groups;

/**
 * Grupo de validación para el NIF
 * 
 * @author isotrol
 */
public interface ConstraintsNif {

}
